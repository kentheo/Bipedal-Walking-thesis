function [q]=inversekinematics(Body_P,Body_R,Dt, Foot_P, Foot_R)

global hip_Comy lengthupperleg lengthunderleg footankletotip footankletoside
a=lengthupperleg;
b=lengthunderleg;
rT=Foot_R'; % transpose
r = rT * (Body_P +  Body_R * Dt - Foot_P);
% C = sqrt(r(1)*r(1)+r(2)*r(2)+r(3)*r(3));
% 
% c5 = (C*C-A*A-B*B)/(2.0*A*B);
% 
% if (c5>=1.0)
%   q(1,4)= 0.0;
% elseif (c5<=-1.0)
%   q(1,4)= pi;
% else 
%   q(1,4)= acos(c5);
% end
	if norm(r,2)>(a+b)
		r = r*(a+b)/norm(r,2);
		disp('out of workspace, scale down');
	end   
	rx=r(1);
	ry=r(2);
	rz=r(3);
	
	c=norm(r,2);
	q4 = pi-acos((a^2+b^2-c^2)/(2*a*b));
	
	alpha=asin(a*sin(pi-q4)/c);
	rxz=sqrt(rx*rx+rz*rz);
	costheta = c/sqrt(rx*rx+rz*rz)*cos(pi/2-alpha);
	x=rxz*sqrt(1-costheta*costheta);
	q5 =atan2(ry,x);
	
	y=c*cos(alpha)-x;
	gama = asin(y*sin(alpha)/rxz);	
	q6 = -(atan2(rx,rz)+gama+alpha);
	
	R34 = [cos(q4) 0 sin(q4);
		0 1 0;
		-sin(q4) 0 cos(q4)];% knee

	R45 = [1 0 0;
		0 cos(q5) -sin(q5);
		0 sin(q5) cos(q5)];% ankle roll


	R56 = [cos(q6) 0 sin(q6);
		0 1 0;
		-sin(q6) 0 cos(q6)];% ankle pitch

	Rfoot_hip=transpose(Body_R)*Foot_R;

	R=Rfoot_hip*transpose(R34*R45*R56);
	
	q1=atan2(R(1,3),R(3,3));
	q3=atan2(R(2,1),R(2,2));
	q2=asin(-R(2,3));

	q=[q1,q2,q3,q4,q5,q6];% with respect to hip coordinate
end