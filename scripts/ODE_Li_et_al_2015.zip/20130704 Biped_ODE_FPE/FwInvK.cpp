/*
    Updated date: 18 Feb 2013
    Copyright (C) 2012 Italian Institute of Technology

    Developer: Zhibin Li
	Email: zhibin.li@iit.it
    Description: this file provides the forward/inverse kinematics for the COMAN arms and legs.
    More detailed information can be found in the accompanying documentation.
*/
#define _USE_MATH_DEFINES
#include <cmath>
#include "MatrixVector.h"

#define RADTODEG(x)  x*180.0/M_PI  // here it overlaps with the definition in global variables, but i leave these here since they are local and used only inside this cpp
#define DEGTORAD(x)  x*M_PI/180.0

const float upperleg=0.22580000;
const float lowerleg=0.2010000;
const float ankle_height = 0.079;
const float fullleg=upperleg+lowerleg+ankle_height;// full leg length
const float hip_offset=0.07260;// from pelvis center to hip joint

const float upperarm = 0.180;
const float forearm = 0.20451;
const float shoulder_offset=0.1535;// from shoulder axis to chest center

Vector3f upperBody_CoM(0.0203,0.0,0.19); //(-0.0072,0.0,0.086); (-0.0027,0.0,0.2306) for upperbody with no battery, (0.0203, 0,0.16)for rod
Vector3f pelvis_CoM(0.025,0,0.06);
Vector3f thigh_CoM(0.00074,0.0,-0.1207);
Vector3f shank_CoM(0.00246,0.0,-0.1467);
Vector3f foot_CoM(0.018,0.0,-0.0559);

const float upperBody_mass = 0.5030; // 3.1-2.9970 is without rod, rod is 1.3kg, 14.8980-2.9970 is with upperbody(no battery)
const float pelvis_m=4.3470;
const float thigh_mass = 3.2150+0.1;
const float shank_mass = 1.4+0.15;
const float foot_mass = 1.39+0.15;
const float total_mass = 2*(thigh_mass+shank_mass+foot_mass)+pelvis_m+upperBody_mass; //15.952 half body with no rod, 19.0 half body with rod, 27.75full body with no battery


void LegInverseKinematics(Vector3f Waist_P,Matrix3f Waist_R,Vector3f Foot_P,Matrix3f Foot_R,  float hipoffset, float *jointangles)
{
	const float A=upperleg;
	const float B=lowerleg;	

	Matrix3f R06T;
	Vector3f Dt, r;

	Dt<<0.0,hipoffset,0.0;

	R06T=Foot_R.transpose();
	r=R06T*(Waist_P+(Waist_R*Dt)-Foot_P);//the vector points from ankle to hip with respect to local foot orientation frame
	float C;//the distance between hip and ankle joint
	float C_reset;//reset C if C is out of range
	C = sqrt(r(0)*r(0)+r(1)*r(1)+r(2)*r(2));

	float kneeMin=DEGTORAD(2);
	float kneeMax=DEGTORAD(120);
	float kneeExtentionMax=sqrt(A*A+B*B-2*A*B*cos(M_PI-kneeMin));
	float kneeExtentionMin=sqrt(A*A+B*B-2*A*B*cos(M_PI-kneeMax));

	if(C>=kneeExtentionMax)
	{
		C_reset=kneeExtentionMax;
		jointangles[3]=kneeMin;
	}
	else if(C<=kneeExtentionMin)
	{
		C_reset=kneeExtentionMin;
		jointangles[3]=kneeMax;
	}
	else
	{
		C_reset=C;
		jointangles[3]= M_PI-acos((A*A+B*B-C_reset*C_reset)/(2.0*A*B));
	}
	float alpha=asin(A*sin(M_PI-jointangles[3])/C_reset);
	float rxz=sqrt(r(0)*r(0)+r(2)*r(2));
	float costheta = C_reset/sqrt(r(0)*r(0)+r(2)*r(2))*cos(M_PI/2-alpha);
	float x=rxz*sqrt(1-costheta*costheta);
	jointangles[4] = atan2(r(1),float(x));
	
	float y=C_reset*cos(alpha)-x;
	float gama = asin(y*sin(alpha)/rxz);	
	jointangles[5] = -(atan2(r(0),r(2))+gama+alpha);
	
	Matrix3f R34, R45, R56, Rfoot_hip, R;
	R34 = Ry(jointangles[3]); // knee
	R45=Rx(jointangles[4]); // ankle roll
	R56=Ry(jointangles[5]); // ankle pitch

	Rfoot_hip=Waist_R.transpose()*Foot_R;
	R=Rfoot_hip*R56.transpose()*R45.transpose()*R34.transpose();
	
	jointangles[0]=atan2(R(0,2),R(2,2));
	jointangles[2]=atan2(R(1,0),R(1,1));
	jointangles[1]=asin(-R(1,2)); 	
}

//
//void InvKHIP(float HipP[3], float HipO[4], float LeftFootP[3], float LFtO[4], float RightFootP[3], float RFtO[4], float *homePos,float *traj_ref)
//{
//	Matrix3f Hip_R, LeftFoot_R, RightFoot_R;
//	Vector3f Hip_P, LeftFoot_Pos,RightFoot_Pos;
//
//	float jointanglesL[6];
//	float jointanglesR[6];
//
//	Hip_R = Rz(HipO[2])*Ry(HipO[1])*Rx(HipO[0])*Rz(HipO[3]);   // body orientation
//	LeftFoot_R = Rz(LFtO[2])*Ry(LFtO[1])*Rx(LFtO[0])*Rz(LFtO[3]);  // left Foot orientation
//	RightFoot_R = Rz(RFtO[2])*Ry(RFtO[1])*Rx(RFtO[0])*Rz(RFtO[3]); // right Foot orientation
//	
//	Hip_P<<HipP[0],HipP[1],HipP[2]; // body position
//	LeftFoot_Pos<<LeftFootP[0],LeftFootP[1],LeftFootP[2];  //left foot position
//	RightFoot_Pos<<RightFootP[0],RightFootP[1],RightFootP[2];  //right foot position
//
//	LegInverseKinematics(Hip_P,Hip_R,LeftFoot_Pos,LeftFoot_R,hip_offset, jointanglesL);
//	LegInverseKinematics(Hip_P,Hip_R,RightFoot_Pos,RightFoot_R,-hip_offset ,jointanglesR);
//
//	/*Joint angles in rad for EPFL COMAN*/
//	traj_ref[3]=jointanglesR[0];//right hip pitch
//	traj_ref[4]=jointanglesL[0];//left hip pitch
//	traj_ref[5]=jointanglesR[1]+DEGTORAD(homePos[5]);//right hip roll
//	traj_ref[6]=jointanglesR[2];//right hip yaw
//	traj_ref[7]=jointanglesR[3];//right knee
//	traj_ref[8]=jointanglesR[5];//right ankle pitch
//	traj_ref[9]=jointanglesR[4];//right ankle roll
//	traj_ref[10]=jointanglesL[1]-DEGTORAD(homePos[10]);//left hip roll
//	traj_ref[11]=jointanglesL[2];//left hip yaw
//	traj_ref[12]=jointanglesL[3];//left knee
//	traj_ref[13]=jointanglesL[5];//left ankle pitch
//	traj_ref[14]=jointanglesL[4];//left ankle roll
//
//	///*Joint angles for old COMAN legs */  // I move conversion into the console, no more here.
//	//traj_ref[3]=(-jointanglesR[0]);// 
//	//traj_ref[4]=(-jointanglesL[0]);	
//	//traj_ref[5]=(jointanglesR[1])+DEGTORAD(homePos[5]);	
//	//traj_ref[6]=(jointanglesR[2]);
//	//traj_ref[7]=(-jointanglesR[3]);
//	//traj_ref[8]=(-jointanglesR[5]);//ankle pitch;
//	//traj_ref[9]=(jointanglesR[4]);//ankle roll;
//	//traj_ref[10]=(-jointanglesL[1])+DEGTORAD(homePos[10]);	
//	//traj_ref[11]=(-jointanglesL[2]);
//	//traj_ref[12]=(-jointanglesL[3]);
//	//traj_ref[13]=(-jointanglesL[5]);//ankle pitch
//	//traj_ref[14]=(-jointanglesL[4]);//ankle roll;
//}


void newLegInverseKinematics(float theta[3], float r_leg, Matrix3f Rfoot, float *jointangles)  // 极坐标系下的逆运动学
{
	// r_leg 腿长 正数标量
	const float A=upperleg;
	const float B=lowerleg;	
	float phiy, alpha, rxz, costheta, x, y, gama;
	float C;//the distance between hip and ankle joint
	float C_reset;//reset C if C is out of range
	Vector3f r_vec1, r_vec2, vec1, vec2, r;
	Matrix3f Rfoot_original, R06T, Foot_R;

	phiy =  atan2(sqrt(tan(theta[0])*tan(theta[0])+tan(theta[1])*tan(theta[1])),1);  

    r_vec1(2) = -r_leg*cos( phiy );
    r_vec1(0) = r_vec1(2)*tan(theta[1]);
    r_vec1(1) = -r_vec1(2)*tan(theta[0]);    
    r_vec2=Rz(theta[2])*r_vec1;
    vec1 << r_vec1(0), r_vec1(1), 0;
    vec2=Rz(DEGTORAD(-90)) * vec1;
	if (vec2.norm()>1e-6)
	{
		vec2=vec2/vec2.norm();
	}

    Rfoot_original = Rz(theta[2])*Rodrigues(vec2,phiy); 
	Foot_R = Rfoot_original*Rfoot; // Rfoot is local rotational operation around foot frame, with respect to hip frame orientation
	R06T=Foot_R.transpose();

	r=-R06T*r_vec2;//the vector points from ankle to hip with respect to local foot orientation frame
	C = r.norm();

	//printf("%3.5f \n",C);

	float kneeMin=DEGTORAD(2);
	float kneeMax=DEGTORAD(120);
	float kneeExtentionMax=sqrt(A*A+B*B-2*A*B*cos(M_PI-kneeMin));
	float kneeExtentionMin=sqrt(A*A+B*B-2*A*B*cos(M_PI-kneeMax));

	if(C>=kneeExtentionMax)
	{
		C_reset=kneeExtentionMax;
		jointangles[3]=kneeMin;
	}
	else if(C<=kneeExtentionMin)
	{
		C_reset=kneeExtentionMin;
		jointangles[3]=kneeMax;
	}
	else
	{
		C_reset=C;
		jointangles[3]= M_PI-acos((A*A+B*B-C_reset*C_reset)/(2.0*A*B));
	}
	r=r*(C_reset/C);

	alpha=asin(A*sin(M_PI-jointangles[3])/C_reset);
	rxz=sqrt(r(0)*r(0)+r(2)*r(2));
	costheta = C_reset/sqrt(r(0)*r(0)+r(2)*r(2))*cos(M_PI/2-alpha);
	x=rxz*sqrt(1-costheta*costheta);
	jointangles[4] = atan2(r(1),float(x));
	
	y=C_reset*cos(alpha)-x;
	gama = asin(y*sin(alpha)/rxz);	
	jointangles[5] = -(atan2(r(0),r(2))+gama+alpha);
	
	Matrix3f R34, R45, R56, Rfoot_hip, R;
	R34 = Ry(jointangles[3]); // knee
	R45=Rx(jointangles[4]); // ankle roll
	R56=Ry(jointangles[5]); // ankle pitch

	R=Foot_R*R56.transpose()*R45.transpose()*R34.transpose();
	
	jointangles[0]=atan2(R(0,2),R(2,2));
	jointangles[2]=atan2(R(1,0),R(1,1));
	jointangles[1]=asin(-R(1,2)); 	
}

void InvKLeg(float theta_left[3], float r_left, float LFtO[4], float FootL[3], float theta_right[3], float r_right, float RFtO[4],float FootR[3], float *homePos,float *traj_ref)
{
	// th_left 虚拟腿向量在极坐标下在投影面上的旋转角度
	// r_left  腿长
	// LFtO 为零的情况下，脚的零姿态平面垂直于虚拟腿向量，所以这个零姿态是相对于这个平面而言的
	Matrix3f LeftFoot_R, RightFoot_R, Rfr, Rfl;
	//Vector3f Hip_P, LeftFoot_Pos,RightFoot_Pos;
	float jointanglesL[6];
	float jointanglesR[6];

	Rfr = Rz(FootR[2])*Ry(FootR[1])*Rx(FootR[0]);  // local operation for admittance
	Rfl = Rz(FootL[2])*Ry(FootL[1])*Rx(FootL[0]);

	LeftFoot_R = Rz(LFtO[2])*Ry(LFtO[1])*Rx(LFtO[0])*Rz(LFtO[3])*Rfl;  // left Foot orientation 
	RightFoot_R = Rz(RFtO[2])*Ry(RFtO[1])*Rx(RFtO[0])*Rz(RFtO[3])*Rfr; // right Foot orientation 

	newLegInverseKinematics(theta_left, r_left, LeftFoot_R, jointanglesL);
	newLegInverseKinematics(theta_right, r_right, RightFoot_R, jointanglesR);

	/*Joint angles in rad for EPFL COMAN*/
	traj_ref[3]=jointanglesR[0];//right hip pitch
	traj_ref[4]=jointanglesL[0];//left hip pitch
	traj_ref[5]=jointanglesR[1]+DEGTORAD(homePos[5]);//right hip roll
	traj_ref[6]=jointanglesR[2];//right hip yaw
	traj_ref[7]=jointanglesR[3];//right knee
	traj_ref[8]=jointanglesR[5];//right ankle pitch
	traj_ref[9]=jointanglesR[4];//right ankle roll
	traj_ref[10]=jointanglesL[1]-DEGTORAD(homePos[10]);//left hip roll
	traj_ref[11]=jointanglesL[2];//left hip yaw
	traj_ref[12]=jointanglesL[3];//left knee
	traj_ref[13]=jointanglesL[5];//left ankle pitch
	traj_ref[14]=jointanglesL[4];//left ankle roll
}

void WholeLegInvK(float theta_left[3], float r_left, float LFtO[4], float theta_right[3], float r_right, float RFtO[4],float *traj_ref)
{
	// th_left 虚拟腿向量在极坐标下在投影面上的旋转角度
	// r_left  腿长
	// LFtO 为零的情况下，脚的零姿态平面垂直于虚拟腿向量，所以这个零姿态是相对于这个平面而言的
	Matrix3f LeftFoot_R, RightFoot_R;
	//Vector3f Hip_P, LeftFoot_Pos,RightFoot_Pos;
	float jointanglesL[6];
	float jointanglesR[6];

	LeftFoot_R = Rz(LFtO[2])*Ry(LFtO[1])*Rx(LFtO[0])*Rz(LFtO[3]);  // left Foot orientation 
	RightFoot_R = Rz(RFtO[2])*Ry(RFtO[1])*Rx(RFtO[0])*Rz(RFtO[3]); // right Foot orientation 

	newLegInverseKinematics(theta_left, r_left, LeftFoot_R, jointanglesL);
	newLegInverseKinematics(theta_right, r_right, RightFoot_R, jointanglesR);

	/*Joint angles in rad for EPFL COMAN*/
	traj_ref[3]=jointanglesR[0];//right hip pitch
	traj_ref[4]=jointanglesL[0];//left hip pitch
	traj_ref[5]=jointanglesR[1];//right hip roll
	traj_ref[6]=jointanglesR[2];//right hip yaw
	traj_ref[7]=jointanglesR[3];//right knee
	traj_ref[8]=jointanglesR[4];//right ankle roll
	traj_ref[9]=jointanglesR[5];//right ankle pitch
	traj_ref[10]=jointanglesL[1];//left hip roll
	traj_ref[11]=jointanglesL[2];//left hip yaw
	traj_ref[12]=jointanglesL[3];//left knee
	traj_ref[13]=jointanglesL[4];//left ankle roll
	traj_ref[14]=jointanglesL[5];//left ankle pitch
}

void newInvKHIP(float HipP[3], float HipO[4], float LeftFootP[3], float LFtO[4], float FootL[3], float RightFootP[3], float RFtO[4],float FootR[3], float *homePos,float *traj_ref)
{
	Matrix3f Hip_R, LeftFoot_R, RightFoot_R, Rfr, Rfl;
	Vector3f Hip_P, LeftFoot_Pos,RightFoot_Pos;
	float jointanglesL[6];
	float jointanglesR[6];

	Rfr = Rz(FootR[2])*Ry(FootR[1])*Rx(FootR[0]);
	Rfl = Rz(FootL[2])*Ry(FootL[1])*Rx(FootL[0]);

	Hip_R = Rz(HipO[2])*Ry(HipO[1])*Rx(HipO[0])*Rz(HipO[3]);   // body orientation
	LeftFoot_R = Rz(LFtO[2])*Ry(LFtO[1])*Rx(LFtO[0])*Rz(LFtO[3])*Rfl;  // left Foot orientation
	RightFoot_R = Rz(RFtO[2])*Ry(RFtO[1])*Rx(RFtO[0])*Rz(RFtO[3])*Rfr; // right Foot orientation
	
	Hip_P<<HipP[0],HipP[1],HipP[2]; // body position
	LeftFoot_Pos<<LeftFootP[0],LeftFootP[1],LeftFootP[2];  //left foot position
	RightFoot_Pos<<RightFootP[0],RightFootP[1],RightFootP[2];  //right foot position

	LegInverseKinematics(Hip_P,Hip_R,LeftFoot_Pos,LeftFoot_R,hip_offset, jointanglesL);
	LegInverseKinematics(Hip_P,Hip_R,RightFoot_Pos,RightFoot_R,-hip_offset ,jointanglesR);

	/*Joint angles in rad for EPFL COMAN*/
	traj_ref[3]=jointanglesR[0];//right hip pitch
	traj_ref[4]=jointanglesL[0];//left hip pitch
	traj_ref[5]=jointanglesR[1]+DEGTORAD(homePos[5]);//right hip roll
	traj_ref[6]=jointanglesR[2];//right hip yaw
	traj_ref[7]=jointanglesR[3];//right knee
	traj_ref[8]=jointanglesR[5];//right ankle pitch
	traj_ref[9]=jointanglesR[4];//right ankle roll
	traj_ref[10]=jointanglesL[1]-DEGTORAD(homePos[10]);//left hip roll
	traj_ref[11]=jointanglesL[2];//left hip yaw
	traj_ref[12]=jointanglesL[3];//left knee
	traj_ref[13]=jointanglesL[5];//left ankle pitch
	traj_ref[14]=jointanglesL[4];//left ankle roll
}

Vector3f LegForwardKinematics(float q[6], float hipoffset, float*leg_pos)
{
	Matrix3f R01, R12, R23, R34,R45,R56, R02, R04, R06;	
	Vector3f A, B, C, D, knee, ankle, foot, seg1, seg2, seg3, leg_com;;

	A<<0,0,-upperleg;
	B<<0,0,-lowerleg;
	C<<0,hipoffset,0;
	D<<0,0,-ankle_height;

	R01 = Ry(q[0]);	// hip pitch	
	R12 = Rx(q[1]);	// hip roll
	R23 = Rz(q[2]);	// hip yaw
	R34 = Ry(q[3]);	// knee
	R45 = Rx(q[4]);	// ankle roll
	R56 = Ry(q[5]);	// ankle pitch

	R02=R01*R12;
	R04=R01*R12*R23*R34;
	R06=R01*R12*R23*R34*R45*R56;

	knee=R02*A+C;// no need to *R23
	ankle=knee+R04*B; // R45 R56 are not needed to calcuate the ankle position
	foot=ankle+R06*D;

	leg_pos[0]=knee(0);
	leg_pos[1]=knee(1);
	leg_pos[2]=knee(2);
    leg_pos[3]=ankle(0);
	leg_pos[4]=ankle(1);
	leg_pos[5]=ankle(2);
	leg_pos[6]=foot(0);  // center of foot
	leg_pos[7]=foot(1);
	leg_pos[8]=foot(2);

	seg1 = C + R01*R12*thigh_CoM;
	seg2 = knee + R04*shank_CoM;
	seg3 = ankle + R06*foot_CoM;
	
	leg_com = (thigh_mass*seg1+shank_mass*seg2+foot_mass*seg3)/(thigh_mass+shank_mass+foot_mass);
	return leg_com;
}


/*------------------------------------------*/
//void LegFWTrajectory(float q[], float legL[6], float legR[6])
//{
//	// q is the vector that contains all the reference/link/motor feedback from robot to pass in
//	float qR[6]={q[3],q[5],q[6],q[7],q[9],q[8]};
//	float qL[6]={q[4],q[10],q[11],q[12],q[14],q[13]};
//	Vector3f com_leg_L, com_leg_R;
//	com_leg_L = LegForwardKinematics(qL, hip_offset, legL);
//	com_leg_R = LegForwardKinematics(qR, -hip_offset,legR);
//	// note that qR follows the correct order of the kinematic chain while q is the 23 element that used in the console that contains all data
//    // LegL/LegR contains the xyz position of the knee and ankle respectively.
//}

Vector3f LegFWTrajectory(float q[], float legL[9], float legR[9])
{
	// q is the vector that contains all the reference/link/motor feedback from robot to pass in
	float qR[6]={q[3],q[5],q[6],q[7],q[9],q[8]};
	float qL[6]={q[4],q[10],q[11],q[12],q[14],q[13]};
	Vector3f com_leg_L, com_leg_R;
	com_leg_L = LegForwardKinematics(qL, hip_offset, legL);
	com_leg_R = LegForwardKinematics(qR, -hip_offset,legR);
	Vector3f com_leg;
	com_leg = 0.5*(com_leg_L+com_leg_R);
	return com_leg;
	// note that qR follows the correct order of the kinematic chain while q is the 23 element that used in the console that contains all data
    // LegL/LegR contains the xyz position of the knee and ankle respectively.
}

/*------------ below are the Fw Inv Kinematics for arms --------------- */


// Geometric solution
void ArmInverseKinematics(Vector3f Body_P,Matrix3f Body_R,Vector3f Hand_P, float handyaw, float offset, float *jointangles)
{
    float q[6];
    const float a=upperarm;
	const float b=forearm;
    float C_original;
    float C_reset;//reset C if C is out of range
	Matrix3f R06T, Rpitch, Rroll, Ryaw, Hand_R, Rxq6,Ryq45,R,RbodyT;;
	Vector3f Dt, r_original, r_scale, r; 

	Dt<<0.0,offset,0;
	r_original=Body_R.transpose()*(Hand_P-Body_P)-Dt;//the vector points from shoulder to wrist to shoulder with respect to local body frame
    // hand virtual orientation is not importance since it doesnt affect position
	C_original = r_original.norm();

	float elbowMin=DEGTORAD(-2);  // to avoid hitting the limit
	float elbowMax=DEGTORAD(-120);// max elbow flexion, 10 degrees margin from real limit
	float armLengthMax=sqrt(a*a+b*b-2*a*b*cos(M_PI+elbowMin));
	float armLengthMin=sqrt(a*a+b*b-2*a*b*cos(M_PI+elbowMax));

	if(C_original>=armLengthMax)
	{
		C_reset=armLengthMax;
		q[3]=elbowMin;
	}
	else if(C_original<=armLengthMin)
	{
		C_reset=armLengthMin;
		q[3]=elbowMax;
	}
	else
	{
		C_reset=C_original;
		q[3]= -(M_PI-acos((a*a+b*b-C_reset*C_reset)/(2.0*a*b)));
	}
    r_scale=r_original*C_reset/C_original;

	float pitch, roll, rxz;
	rxz=sqrtf(r_scale(0)*r_scale(0)+r_scale(2)*r_scale(2));
	pitch=atan2(-r_scale(0),-r_scale(2));
	roll=atan2(r_scale(1),rxz);

    Rpitch= Ry(pitch); // hand virtual pitch
    Rroll = Rx(roll);// hand virtual roll
	Ryaw  = Rz(handyaw);// hand virtual yaw specified by user

    Hand_R=Rpitch*Rroll*Ryaw; // here the yaw is the local yaw around the vector from shoulder to hand

	R06T=Hand_R.transpose();
	r=R06T*(Body_P+(Body_R*Dt)-Hand_P);//the vector points from wrist to shoulder with respect to local wrist orientation frame

	float alpha=asin(a*sin(M_PI+q[3])/C_reset);//the angle at the bottom in triangle
	q[5] = atan2(r(1),r(2));//ankle roll -pi/2<q6<pi/2
	if (q[5]>M_PI/2.0)
	{
		q[5] = q[5]-M_PI;
	}
	else if (q[5]<-M_PI/2.0)
	{
		q[5]= q[5]+M_PI;
	}

	// ankle pitch
	if (r(2)>0.0)
	{
		q[4] = -( atan2( r(0),sqrt(r(1)*r(1)+r(2)*r(2)) ) - alpha );
	}
	else
	{
		q[4] = -( atan2( r(0),-sqrt(r(1)*r(1)+r(2)*r(2)) ) - alpha );
	}
	/*-- Rfoot=Rbody*Ry(q1)*Rx(q2)*Rz(q3)*Ry(q4)*Ry(q5)*Rx(q6) ----*/
	/*-- Rfoot=Rbody*Ry(q1)*Rx(q2)*Rz(q3)*Ry(q4+q5)*Rx(q6) ----*/
	/*-- => Ry(q1)*Rx(q2)*Rz(q3)= Rbody^T * Rfoot * Rx(q6)^T * Ry(q5)^T *Ry(q4)^T --*/
	/*--or => Ry(q1)*Rx(q2)*Rz(q3)= Rbody^T * Rfoot * Rx(q6)^T * Ry(q5+q4)^T --*/
	/*Note: Rx(q)^T = Rx(-q), so we dont need to transpose, make code easier*/
	RbodyT = Body_R.transpose();
	Rxq6 = Rx(-q[5]);
	Ryq45 = Ry(-q[3]-q[4]);
	R = RbodyT*( Hand_R*(Rxq6*Ryq45) );
	/*Ry(q1)*Rx(q2)*Rz(q3)=R*/
	//here, the pitch-roll-yaw means the joint configuration of the arm/shoulder.
/*
	Ry*Rx*Rz=
	[  cos(yaw)*cos(pitch)+sin(yaw)*sin(roll)*sin(pitch), -sin(yaw)*cos(pitch)+cos(yaw)*sin(roll)*sin(pitch),                               cos(roll)*sin(pitch)]
	[                                 sin(yaw)*cos(roll),                                 cos(yaw)*cos(roll),                                         -sin(roll)]
	[ -cos(yaw)*sin(pitch)+sin(yaw)*sin(roll)*cos(pitch),  sin(yaw)*sin(pitch)+cos(yaw)*sin(roll)*cos(pitch),                               cos(roll)*cos(pitch)]
*/
 	q[2] = atan2(R(1,0),R(1,1)); //Z hip yaw  Y-X-Z
	q[0] = atan2(R(0,2),R(2,2)); //Y hip pitch
	//q[1] = atan2(-R(2,3),(R(1,3)*sin(jointangles[0]) + R(3,3)*cos(jointangles[0]))); // it is the same as asin(-R(2,3))
	q[1]=asin(-R(1,2)); // the same
	for(int i=0;i<4;i++)
	{
	    jointangles[i]=q[i]; // asign value
	}
}


void ArmIKTrajectory(float BodyP[3], float BodyO[3],float LeftHandP[3],float yawArmL, float RightHandP[3],float yawArmR,float *traj)
{
	Matrix3f Body_R, LeftHand_R,  RightHand_R;
	Vector3f Body_P, LeftHand_Pos,RightHand_Pos;
	float leftArm[4];// last tow joints (wrist) dont exist
	float rightArm[4];

	/*body orientation*/
	Body_R = Rz(BodyO[2])*Ry(BodyO[1])*Rx(BodyO[0]);   // body orientation

	/*body position*/
	Body_P<<BodyP[0],BodyP[1],BodyP[2];
	/*left foot position*/
	LeftHand_Pos<<LeftHandP[0],LeftHandP[1],LeftHandP[2];
	/*right foot position*/
	RightHand_Pos<<RightHandP[0],RightHandP[1],RightHandP[2];

    ArmInverseKinematics(Body_P,Body_R,LeftHand_Pos, yawArmL, shoulder_offset,leftArm);
	ArmInverseKinematics(Body_P,Body_R,RightHand_Pos,yawArmR, -shoulder_offset,rightArm);
	// below is already converted to EPFL convention
	/*Joint angles of arms */
	traj[15]=rightArm[0];// right arm pitch
	traj[16]=rightArm[1]+0.5*M_PI;// right arm roll
	traj[17]=rightArm[2];// right arm yaw
	traj[18]=rightArm[3];// right elbow

	traj[19]=leftArm[0];// left arm pitch
	traj[20]=leftArm[1]-0.5*M_PI;// left arm roll
	traj[21]=leftArm[2];// left arm yaw
	traj[22]=leftArm[3];// left elbow
}

/*------------------------------------------*/
void ArmForwardKinematics(float q[], float shoulderoffset, float*arm_pos)
{
	Matrix3f R01, R12, R23, R34;
	Vector3f A, B, C, elbow, wrist;
	A<<0,0,-upperarm;
	B<<0,0,-forearm;
	C<<0,shoulderoffset,0;

	R01 = Ry(q[0]); // shoulder pitch
	R12 = Rx(q[1]); // shoulder roll
	R23 = Rz(q[2]); // shoulder yaw
	R34 = Ry(q[3]); // elbow

	elbow=R01*R12*R23*A+C;
	wrist=elbow+R01*R12*R23*R34*B;

	arm_pos[0]=elbow(0);
	arm_pos[1]=elbow(1);
	arm_pos[2]=elbow(2);
	arm_pos[3]=wrist(0);
	arm_pos[4]=wrist(1);
	arm_pos[5]=wrist(2);
}
/*------------------------------------------*/
void ArmFWTrajectory(float q[], float armL[6], float armR[6])
{
	// q is the vector that contains all the link/motor feedback from robot, already considers the convention
	float qL[4]={q[19],q[20]+0.5*M_PI,q[21],q[22]};
	float qR[4]={q[15],q[16]-0.5*M_PI,q[17],q[18]};
	ArmForwardKinematics(qL, shoulder_offset, armL);
	ArmForwardKinematics(qR, -shoulder_offset, armR);
}
/*------------------------------------------*/

Vector3f WholeBodyState(float q[], Matrix3f Rwaist, float legL[9], float legR[9])
{
	Vector3f com_leg, com_whole;
    com_leg = LegFWTrajectory(q, legL, legR);

	com_whole=( (thigh_mass+shank_mass+foot_mass)*com_leg+upperBody_mass*upperBody_CoM+ pelvis_m*pelvis_CoM )/total_mass;
	return com_whole;
}
