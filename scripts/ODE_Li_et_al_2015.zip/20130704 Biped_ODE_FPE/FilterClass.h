#ifndef _Filter_H// header guards
#define _Filter_H

#define MAX_FILTER_LENGTH 8
//typedef double float; //number type
#define _USE_MATH_DEFINES
#include <cmath>

class FilterClass 
{
	
public:
	//Define Variables
	//************************************************************************************
	int Ncoeff; 					// Number of coefficients
	float x[MAX_FILTER_LENGTH]; 	// Circular buffer of incoming values to be filtered
	float y[MAX_FILTER_LENGTH];		// Result and accumulators
	float a[MAX_FILTER_LENGTH];		// Y coefficient
	float b[MAX_FILTER_LENGTH];		// X coefficient
	FilterClass();
	/*End Variables definition
	************************************************************************************
	************************************************************************************
	//Begin function heders
	************************************************************************************/
	void clear_filter();  //set values to 0
	void int_diff_filter(float X);
	/*Filter Functions
	T is the sampleTime in second	
	cutoff is the cutoff frequency in Hz
	N is the order of the filter*/

	void least_squares_filter(float T, int N); 
	void moving_average_filter(int N);
	void butterworth(float T, float cutoff, int N);
	void butterDifferentiator(float T, float cutoff, int N);

	//Use Filter Function
	float applyFilter(float input);
	float differentiator(float input);
	//end Functions
};
#endif