% updated 21 Jan 2011
% updated  14 Dec 2012
clc
clear ExportAngle ExportTime x xx xt xxt y yy transitionR transitionL transitionRend transitionLend
clear RightHRP LeftHRP blank ExportVelocity Angle qR_exp qL_exp

[row col]=size(qR2);
if row>col
    qR_exp=qR;
    qL_exp=qL;
else
    qR_exp=qR';
    qL_exp=qL';
end
clear row col

for i=1:6
    x = [0, 0.5]; % transition duration
    xt=min(x):T:max(x); 
    y= [0  qR_exp(1,i)];    
    yy= [qR_exp(end,i) 0];
    
    transitionR(:,i) = spline(x, [0 y 0], xt);
    transitionRend(:,i) = spline(x, [0 yy 0], xt);
    
    y = [ 0  qL_exp(1,i)];    
    yy = [qL_exp(end,i)  0];
    transitionL(:,i) = spline(x, [0 y 0], xt);
    transitionLend(:,i) = spline(x, [0 yy 0], xt);
end
% connect transition parts
Right = [transitionR; qR_exp ; transitionRend];
Left = [transitionL; qL_exp ; transitionLend];

t=T*[1:length(Right(:,1))]';
dT = 0.001; % max control time step in simulation
time = [t(1):dT:t(end)]';

Angle = [Right Left];

for i=1:12
    ExportAngle(:,i) = interp1(t, Angle(:,i), time);
end
%% COMAN new joint definition
% save Ref.txt -ASCII -DOUBLE -TABS Angle;
% save(['../CalCOM_Matlab/Ref.mat'], 'Angle');
% save time.txt -ASCII -DOUBLE -TABS time;
% save Ref.txt -ASCII -DOUBLE -TABS ExportAngle;
row=length(time);
fid=fopen('C:\Documents and Settings\zli\Documents\MBProjects\CoMan_LegsCad_23Dof_V4_FB_NoBattery_NoPC\workR\Ref.txt','w');
for i=1:row
    fprintf(fid, '%12.8f\t', time(i));       
    for j=1:12
        fprintf(fid, '%12.8f\t', ExportAngle(i,j));        
    end
    fprintf(fid, '\n');
end
fclose(fid);
