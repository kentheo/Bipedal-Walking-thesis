class ActuatorClass{
	public:
		float ActuatorUnit(float T, float real_time, float target_time, float target_pos,float v_limit,float a_limit, float fn); // default target velocity is zero.

	private:
		float Poly3Intpl(float time, float t0, float ds0, float s0, float tf, float dsf, float sf);
		void Proxy_Model(float T, float xnow[3], float xdes, float fn, float v_limit, float a_limit, float *s_filter);
};