#include <Eigen/Dense>
using namespace Eigen;

extern Matrix3f Rx(float);
extern Matrix3f Ry(float);
extern Matrix3f Rz(float);
extern Matrix3f Rodrigues(Vector3f w,float theta);