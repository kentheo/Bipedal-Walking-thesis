// here decleare the functions in FPEControl.cpp that will be used by other cpp files.
#include "WholeBodySensing.h"
#include "COMANParameter.h"

#define _USE_MATH_DEFINES
#include <cmath>

extern void FPEControl(float *traj_ref,float *fpepos);
extern void SetWalkState(opstate Mode);
