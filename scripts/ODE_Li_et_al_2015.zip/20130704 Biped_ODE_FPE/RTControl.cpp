#include "WholeBodySensing.h"
#include "COMANParameter.h"
#include "FwInvK.h"
#include "FilterClass.h"

#define _USE_MATH_DEFINES
#include <cmath>

#define DEGTORAD(x)  x*M_PI/180.0
#define RADTODEG(x)  x*180.0/M_PI

// below are state variables
_irobot robot_state; // log out data structure
Vector3f Lft_vec, Rft_vec, COP_COM_vec;
// below are the variables used for control
float LFtO[4]={0,0,0,0};
float RFtO[4]={0,0,0,0};


struct _flag
{ 
	bool enable;
	bool done;
};
_flag attitude={0,0};
_flag landing={0,0};
_flag legextension={0,0};
_flag SMFlag={0,0};

float th_right[3];	// about x y z axes
float dth_right[3];
float ddth_right[3];
float r_right_des=THIGH_HEIGHT+CALF_HEIGHT;
float r_right=r_right_des; 
float dr_right;
float ddr_right;

float th_left[3];  // x y z 
float dth_left[3];
float ddth_left[3];
float r_left_des=THIGH_HEIGHT+CALF_HEIGHT;
float r_left=r_left_des; 
float dr_left;
float ddr_left;

float th_attack[4];
float th_swing_des;



//float th_stance[2];	// virtual stance leg angle, COM with respect to COP
float th_swing[2];	// virtual swing leg angle

float th_virtual[2];	// virtual stance leg angle, COM with respect to COP
float Lft_ang[2];	// virtual stance leg angle, COM with respect to left foot
float Rft_ang[2];	// virtual swing leg angle, COM with respect to right foot

float Lft_vel[2];	// virtual stance leg angle, COM with respect to left foot
float Rft_vel[2];	// virtual swing leg angle, COM with respect to right foot

bool is_filter_int=0;

float th_hip[3]; // desired hip orientation angles

static float Fmin=10;
static short int contact_state; //

const short int N=3;
const short int bsize=2*N;
float th_buffer[bsize];
float dth_buffer[bsize];

float L_left, L_right, w, th, th_f; // feedback variables from state feedback

void AttitudeControl(float dT, int dtime, float n, float LFtO[4],float RFtO[4],float EulerAng[3], float EulerVel[3]);
void FPControl(float dT,int dtime, float traj_ref[30], float EulerAng[3],float EulerVel[3]);
void StateFeedback(float dT, int dtime, float traj_ref[30], float EulerAng[3],float EulerVel[3], float *passdata);
void LeftSwingLegControl(float dT);

FilterClass filter_Lft_vel0,filter_Lft_vel1, filter_Rft_vel0,filter_Rft_vel1;
//////////////////////////////////////////////////////
///////////////////////////////////
float th_lr[4];
float Ek0_lr[4];
float Ekf_lr[4];
float L_lr[4];
float L_lr_drop[4];
float fpe[4];
/////////////////////////////////////
//_irobot robot_state; // log out data structure

const float StepForwardThreshold = 0.01;
const float StepBehindThreshold = 0.01;
const float Swing_Trans_Thres=0.01;
float Lift_Height=0.05;
const float g=9.81;
const float pi=3.1416;

float KneeRate=0.005;
float HipRate=0.005;
float SwingKneeRate=0.01;
float SwingHipRate=0.02;
float FminFPE=30;

walkstate WalkingState=STAND;
opstate WalkMode=WALK;

//////////////////////////////////////////////////////
void SetWalkState(opstate Mode)
{
	WalkMode=Mode;
}
void FPEControl(float dT,int LOOP)
{	
	// blue leg is left, red is right
	static float k=0.5;
	bool LftLead= Lft_vec(0) > Rft_vec(0);
	bool RftLead= Lft_vec(0) < Rft_vec(0);
	
	static float FPE_OFFSET=0.01;
	//fpe[0]+=FPE_OFFSET;
	//fpe[2]+=FPE_OFFSET;

	bool L_FPELead=(fpe[0] - Lft_vec(0)) > StepForwardThreshold;
	bool FPEBack=0;
	bool R_FPELead=(fpe[2] - Rft_vec(0)) > StepForwardThreshold;

	static float left_ang,right_ang;
	static float Tfilter = 1.0/5.0;

	if(SMFlag.done){
		left_ang=th_left[1];
		right_ang=th_right[1];
	}
	if(SMFlag.enable){
		th_left[1]=left_ang;
		th_right[1]=right_ang;
	}
	
	//static float a=robot_state.FT_fl_filter(2)/(robot_state.m*g);
	//static float b=robot_state.FT_fr_filter(2)/(robot_state.m*g);
	//static float kp=30;

	static float Tn1,fn1,kp1,damping1,kd1; // for hip angle
	static float Tn2,fn2,kp2,damping2,kd2; // for leg extension
	Tn1=0.4; // swing leg needs to be fast enough, time constant for reaching desired position
	fn1=1/Tn1;
	kp1=4*pi*pi*fn1*fn1;
	damping1=0.8;
	kd1=2*damping1*sqrt(kp1);

	Tn2=0.3; // leg extension, time constant for reaching desired position
	fn2=1/Tn2;
	kp2=4*pi*pi*fn2*fn2;
	damping2=0.8;
	kd2=2*damping2*sqrt(kp2);
	static float kp3=15.5,kd3=0.315; // for body attitute	

	static float kp=30,kd=0.5;
	static float kfpe=0.7;
	kfpe+=kp*(robot_state.IMU_rel*robot_state.dcom)(0)*dT+kd*(robot_state.IMU_rel*robot_state.ddcom)(0)*dT*dT;
	th_attack[1]*=kfpe;
	th_attack[3]*=kfpe;
	fpe[0]*=kfpe;
	fpe[2]*=kfpe;

	if(WalkingState==STAND){
		if(LftLead){
			if(WalkMode==WALK){
				WalkingState=R_LIFT;			
			}
			else if(R_FPELead){
				WalkingState=R_LIFT;
			}
			else if(FPEBack){
				WalkingState=L_LIFT;
			}
		}
		else if(RftLead){
			if(WalkMode==WALK){
				WalkingState=L_LIFT;			
			}
			else if(L_FPELead){
				WalkingState=L_LIFT;
			}
			else if(FPEBack){
				WalkingState=R_LIFT;
			}
		}
		else{ // ˫�Ų���վ��
			WalkingState=L_LIFT;
		}
	}

	else if(WalkingState==L_PUSH){
		dth_right[1] = kp3*robot_state.IMU_angle(1) + kd3*robot_state.IMU_d_angle(1);
		th_right[1] = th_right[1] + dth_right[1]*dT;
		//th_right[1]+=(b)*kp*robot_state.IMU_angle(1)*dT;//to hold torso upright	
		if(r_left<0.99*r_left_des){
			r_left =(0.2*Tfilter*r_left+dT*r_left_des)/(0.2*Tfilter+dT);		
		}
		else{
			WalkingState=L_LIFT;			
		}
	}

	else if(WalkingState==L_LIFT){
		dth_right[1] = kp3*robot_state.IMU_angle(1) + kd3*robot_state.IMU_d_angle(1);
		th_right[1] = th_right[1] + dth_right[1]*dT;//to hold torso upright
		if((-Rft_vec(2)+Lft_vec(2)) < Lift_Height){
			r_left =(0.5*Tfilter*r_left+dT*0.5*r_left_des)/(0.5*Tfilter+dT);
			r_right =(Tfilter*r_right+dT*0.8*r_right_des)/(Tfilter+dT);
		}
		else{
			WalkingState=L_SWING;
		}
	}

	else if(WalkingState==L_SWING){
		dth_right[1] = kp3*robot_state.IMU_angle(1) + kd3*robot_state.IMU_d_angle(1);
		th_right[1] = th_right[1] + dth_right[1]*dT;//to hold torso upright	
		if(abs(fpe[0] - Lft_vec(0)) > Swing_Trans_Thres && abs(th_left[1] + th_attack[1]) > Swing_Trans_Thres){
			//th_left[1] =(0.2*Tfilter*th_left[1]-dT*th_attack[1])/(0.2*Tfilter+dT);
			ddth_left[1] = kp1*(-th_attack[1]-th_left[1]) - kd1*dth_left[1];
			th_left[1] = th_left[1] + dth_left[1]*dT + 0.5*ddth_left[1]*dT*dT;
			dth_left[1] = dth_left[1] + ddth_left[1]*dT;
			if(Rft_vec(0)>Lft_vec(0)){
				r_left =(Tfilter*r_left+dT*0.7*r_left_des)/(Tfilter+dT);
			}
			else{				
				ddr_left = kp2*(r_left_des-r_left) - kd2*dr_left;
				r_left = r_left + dr_left*dT + 0.5*ddr_left*dT*dT;
				dr_left = dr_left + ddr_left*dT;
				//r_left =(0.5*Tfilter*r_left+dT*L_lr_drop[1])/(0.5*Tfilter+dT);
				r_right =(0.5*Tfilter*r_right+dT*r_right_des)/(0.5*Tfilter+dT);
			}								
		}
		else{
			WalkingState=L_DROP;
		}	
	}

	else if(WalkingState==L_DROP){
		dth_right[1] = kp3*robot_state.IMU_angle(1) + kd3*robot_state.IMU_d_angle(1);
		th_right[1] = th_right[1] + dth_right[1]*dT;//to hold torso upright	
		if(robot_state.FT_fl_filter(2)<FminFPE){
			r_left =(Tfilter*r_left+dT*L_lr_drop[1])/(Tfilter+dT);
			th_left[1] =(Tfilter*th_left[1]-dT*th_attack[1])/(Tfilter+dT);
			r_right =(Tfilter*r_right+dT*r_right_des)/(Tfilter+dT);
		}
		else{
			if(WalkMode==WALK){
				WalkingState=R_PUSH;
			}
			else{
				WalkingState=STAND;
			}		
		}
	}
	
	/// Right Foot
	else if(WalkingState==R_PUSH){
		dth_left[1] = kp3*robot_state.IMU_angle(1) + kd3*robot_state.IMU_d_angle(1);
		th_left[1] = th_left[1] + dth_left[1]*dT;//to hold torso upright
		if(r_right<0.99*r_right_des){
			r_right =(0.2*Tfilter*r_right+dT*r_right_des)/(0.2*Tfilter+dT);
		}
		else{
			WalkingState=R_LIFT;
		}
	}

	else if(WalkingState==R_LIFT){
		dth_left[1] = kp3*robot_state.IMU_angle(1) + kd3*robot_state.IMU_d_angle(1);
		th_left[1] = th_left[1] + dth_left[1]*dT;//to hold torso upright
		if((-Lft_vec(2)+Rft_vec(2)) < Lift_Height){
			r_right =(0.5*Tfilter*r_right+dT*0.5*r_right_des)/(0.5*Tfilter+dT);			
			r_left =(Tfilter*r_left+dT*0.8*r_left_des)/(Tfilter+dT);
		}
		else{
			WalkingState=R_SWING;
		}
	}

	else if(WalkingState==R_SWING){
		dth_left[1] = kp3*robot_state.IMU_angle(1) + kd3*robot_state.IMU_d_angle(1);
		th_left[1] = th_left[1] + dth_left[1]*dT;//to hold torso upright
		if(abs(fpe[2] -Rft_vec(0)) > Swing_Trans_Thres && abs(th_right[1] + th_attack[3]) > Swing_Trans_Thres){
			//th_right[1] =(0.2*Tfilter*th_right[1]-dT*th_attack[3])/(0.2*Tfilter+dT);
			ddth_right[1] = kp1*(-th_attack[3]-th_right[1]) - kd1*dth_right[1];
			th_right[1] = th_right[1] + dth_right[1]*dT + 0.5*ddth_right[1]*dT*dT;
			dth_right[1] = dth_right[1] + ddth_right[1]*dT;
			if(Lft_vec(0)>Rft_vec(0)){
				r_right =(Tfilter*r_right+dT*0.7*r_right_des)/(Tfilter+dT);
			}
			else{
				ddr_right = kp2*(r_right_des-r_right) - kd2*dr_right;
				r_right = r_right + dr_right*dT + 0.5*ddr_right*dT*dT;
				dr_right = dr_right + ddr_right*dT;
				//r_right =(0.2*Tfilter*r_right+dT*L_lr_drop[3])/(0.2*Tfilter+dT);
				r_left =(0.5*Tfilter*r_left+dT*r_left_des)/(0.5*Tfilter+dT);
			}
		}
		else{
			WalkingState=R_DROP;
		}	
	}

	else if(WalkingState==R_DROP){
		dth_left[1] = kp3*robot_state.IMU_angle(1) + kd3*robot_state.IMU_d_angle(1);
		th_left[1] = th_left[1] + dth_left[1]*dT;//to hold torso upright
		if(robot_state.FT_fr_filter(2)<FminFPE){ 
			r_right =(Tfilter*r_right+dT*L_lr_drop[3])/(Tfilter+dT);
			th_right[1] =(Tfilter*th_right[1]-dT*th_attack[3])/(Tfilter+dT);
			r_left =(Tfilter*r_left+dT*r_left_des)/(Tfilter+dT);
		}
		else{
			if(WalkMode==WALK){
				WalkingState=L_PUSH;
			}
			else{
				WalkingState=STAND;
			}		
		}
	}
    


}


//void FPEControl(float dT,int LOOP)
//{	
//	// blue leg is left, red is right
//	static float k=0.5;
//	bool LftLead= Lft_vec(0) > Rft_vec(0);
//	bool RftLead= Lft_vec(0) < Rft_vec(0);
//	
//	static float FPE_OFFSET=0.01;
//	//fpe[0]+=FPE_OFFSET;
//	//fpe[2]+=FPE_OFFSET;
//
//	bool L_FPELead=(fpe[0] - Lft_vec(0)) > StepForwardThreshold;
//	bool FPEBack=0;
//	bool R_FPELead=(fpe[2] - Rft_vec(0)) > StepForwardThreshold;
//
//	static float left_ang,right_ang;
//	static float Tfilter = 1.0/5.0;
//
//	if(SMFlag.done){
//		left_ang=th_left[1];
//		right_ang=th_right[1];
//	}
//	if(SMFlag.enable){
//		th_left[1]=left_ang;
//		th_right[1]=right_ang;
//	}
//	
//
//	//static float a=robot_state.FT_fl_filter(2)/(robot_state.m*g);
//	//static float b=robot_state.FT_fr_filter(2)/(robot_state.m*g);
//	//static float kp=30;
//
//	static float Tn1,fn1,kp1,damping1,kd1; // for hip angle
//	static float Tn2,fn2,kp2,damping2,kd2; // for leg extension
//	Tn1=0.4; // swing leg needs to be fast enough, time constant for reaching desired position
//	fn1=1/Tn1;
//	kp1=4*pi*pi*fn1*fn1;
//	damping1=0.8;
//	kd1=2*damping1*sqrt(kp1);
//
//	Tn2=0.3; // leg extension, time constant for reaching desired position
//	fn2=1/Tn2;
//	kp2=4*pi*pi*fn2*fn2;
//	damping2=0.8;
//	kd2=2*damping2*sqrt(kp2);
//	static float kp3=20,kd3=0.5; // for body attitute	
//
//	static float kp=30,kd=0.5;
//	static float kfpe=0.8;
//	kfpe+=kp*(robot_state.IMU_rel*robot_state.dcom)(0)*dT+kd*(robot_state.IMU_rel*robot_state.ddcom)(0)*dT*dT;
//	th_attack[1]*=kfpe;
//	th_attack[3]*=kfpe;
//	fpe[0]*=kfpe;
//	fpe[2]*=kfpe;
//
//	if(WalkingState==STAND){
//		if(LftLead){
//			if(WalkMode==WALK){
//				WalkingState=R_LIFT;			
//			}
//			else if(R_FPELead){
//				WalkingState=R_LIFT;
//			}
//			else if(FPEBack){
//				WalkingState=L_LIFT;
//			}
//		}
//		else if(RftLead){
//			if(WalkMode==WALK){
//				WalkingState=L_LIFT;			
//			}
//			else if(L_FPELead){
//				WalkingState=L_LIFT;
//			}
//			else if(FPEBack){
//				WalkingState=R_LIFT;
//			}
//		}
//		else{ // ˫�Ų���վ��
//			WalkingState=L_LIFT;
//		}
//	}
//
//	else if(WalkingState==L_PUSH){
//		dth_right[1] = kp3*robot_state.IMU_angle(1) + kd3*robot_state.IMU_d_angle(1);
//		th_right[1] = th_right[1] + dth_right[1]*dT;
//		//th_right[1]+=(b)*kp*robot_state.IMU_angle(1)*dT;//to hold torso upright	
//		if(r_left<0.99*r_left_des){
//			r_left =(0.2*Tfilter*r_left+dT*r_left_des)/(0.2*Tfilter+dT);		
//		}
//		else{
//			WalkingState=L_LIFT;			
//		}
//	}
//
//	else if(WalkingState==L_LIFT){
//		dth_right[1] = kp3*robot_state.IMU_angle(1) + kd3*robot_state.IMU_d_angle(1);
//		th_right[1] = th_right[1] + dth_right[1]*dT;//to hold torso upright
//		if((-Rft_vec(2)+Lft_vec(2)) < Lift_Height){
//			r_left =(0.5*Tfilter*r_left+dT*0.5*r_left_des)/(0.5*Tfilter+dT);
//			r_right =(Tfilter*r_right+dT*0.8*r_right_des)/(Tfilter+dT);
//		}
//		else{
//			WalkingState=L_SWING;
//		}
//	}
//
//	else if(WalkingState==L_SWING){
//		dth_right[1] = kp3*robot_state.IMU_angle(1) + kd3*robot_state.IMU_d_angle(1);
//		th_right[1] = th_right[1] + dth_right[1]*dT;//to hold torso upright	
//		if(abs(fpe[0] - Lft_vec(0)) > Swing_Trans_Thres && abs(th_left[1] + th_attack[1]) > Swing_Trans_Thres){
//			//th_left[1] =(0.2*Tfilter*th_left[1]-dT*th_attack[1])/(0.2*Tfilter+dT);
//			ddth_left[1] = kp1*(-th_attack[1]-th_left[1]) - kd1*dth_left[1];
//			th_left[1] = th_left[1] + dth_left[1]*dT + 0.5*ddth_left[1]*dT*dT;
//			dth_left[1] = dth_left[1] + ddth_left[1]*dT;
//			if(Rft_vec(0)>Lft_vec(0)){
//				r_left =(Tfilter*r_left+dT*0.7*r_left_des)/(Tfilter+dT);
//			}
//			else{				
//				ddr_left = kp2*(r_left_des-r_left) - kd2*dr_left;
//				r_left = r_left + dr_left*dT + 0.5*ddr_left*dT*dT;
//				dr_left = dr_left + ddr_left*dT;
//				//r_left =(0.5*Tfilter*r_left+dT*L_lr_drop[1])/(0.5*Tfilter+dT);
//				r_right =(0.5*Tfilter*r_right+dT*r_right_des)/(0.5*Tfilter+dT);
//			}								
//		}
//		else{
//			WalkingState=L_DROP;
//		}	
//	}
//
//	else if(WalkingState==L_DROP){
//		dth_right[1] = kp3*robot_state.IMU_angle(1) + kd3*robot_state.IMU_d_angle(1);
//		th_right[1] = th_right[1] + dth_right[1]*dT;//to hold torso upright	
//		if(robot_state.FT_fl_filter(2)<FminFPE){
//			r_left =(Tfilter*r_left+dT*L_lr_drop[1])/(Tfilter+dT);
//			th_left[1] =(Tfilter*th_left[1]-dT*th_attack[1])/(Tfilter+dT);
//			r_right =(Tfilter*r_right+dT*r_right_des)/(Tfilter+dT);
//		}
//		else{
//			if(WalkMode==WALK){
//				WalkingState=R_PUSH;
//			}
//			else{
//				WalkingState=STAND;
//			}		
//		}
//	}
//	
//	/// Right Foot
//	else if(WalkingState==R_PUSH){
//		dth_left[1] = kp3*robot_state.IMU_angle(1) + kd3*robot_state.IMU_d_angle(1);
//		th_left[1] = th_left[1] + dth_left[1]*dT;//to hold torso upright
//		if(r_right<0.99*r_right_des){
//			r_right =(0.2*Tfilter*r_right+dT*r_right_des)/(0.2*Tfilter+dT);
//		}
//		else{
//			WalkingState=R_LIFT;
//		}
//	}
//
//	else if(WalkingState==R_LIFT){
//		dth_left[1] = kp3*robot_state.IMU_angle(1) + kd3*robot_state.IMU_d_angle(1);
//		th_left[1] = th_left[1] + dth_left[1]*dT;//to hold torso upright
//		if((-Lft_vec(2)+Rft_vec(2)) < Lift_Height){
//			r_right =(0.5*Tfilter*r_right+dT*0.5*r_right_des)/(0.5*Tfilter+dT);			
//			r_left =(Tfilter*r_left+dT*0.8*r_left_des)/(Tfilter+dT);
//		}
//		else{
//			WalkingState=R_SWING;
//		}
//	}
//
//	else if(WalkingState==R_SWING){
//		dth_left[1] = kp3*robot_state.IMU_angle(1) + kd3*robot_state.IMU_d_angle(1);
//		th_left[1] = th_left[1] + dth_left[1]*dT;//to hold torso upright
//		if(abs(fpe[2] -Rft_vec(0)) > Swing_Trans_Thres && abs(th_right[1] + th_attack[3]) > Swing_Trans_Thres){
//			//th_right[1] =(0.2*Tfilter*th_right[1]-dT*th_attack[3])/(0.2*Tfilter+dT);
//			ddth_right[1] = kp1*(-th_attack[3]-th_right[1]) - kd1*dth_right[1];
//			th_right[1] = th_right[1] + dth_right[1]*dT + 0.5*ddth_right[1]*dT*dT;
//			dth_right[1] = dth_right[1] + ddth_right[1]*dT;
//			if(Lft_vec(0)>Rft_vec(0)){
//				r_right =(Tfilter*r_right+dT*0.7*r_right_des)/(Tfilter+dT);
//			}
//			else{
//				ddr_right = kp2*(r_right_des-r_right) - kd2*dr_right;
//				r_right = r_right + dr_right*dT + 0.5*ddr_right*dT*dT;
//				dr_right = dr_right + ddr_right*dT;
//				//r_right =(0.2*Tfilter*r_right+dT*L_lr_drop[3])/(0.2*Tfilter+dT);
//				//r_left =(0.5*Tfilter*r_left+dT*r_left_des)/(0.5*Tfilter+dT);
//			}
//		}
//		else{
//			WalkingState=R_DROP;
//		}	
//	}
//
//	else if(WalkingState==R_DROP){
//		dth_left[1] = kp3*robot_state.IMU_angle(1) + kd3*robot_state.IMU_d_angle(1);
//		th_left[1] = th_left[1] + dth_left[1]*dT;//to hold torso upright
//		if(robot_state.FT_fr_filter(2)<FminFPE){ 
//			r_right =(Tfilter*r_right+dT*L_lr_drop[3])/(Tfilter+dT);
//			th_right[1] =(Tfilter*th_right[1]-dT*th_attack[3])/(Tfilter+dT);
//			r_left =(0.5*Tfilter*r_left+dT*r_left_des)/(0.5*Tfilter+dT);
//		}
//		else{
//			if(WalkMode==WALK){
//				WalkingState=L_PUSH;
//			}
//			else{
//				WalkingState=STAND;
//			}		
//		}
//	}
//    
//
//
//}
//

void initilizeFilter(float dT, float cutoff, int N)
{	
	filter_Lft_vel0.butterDifferentiator(dT, cutoff, N);
	filter_Rft_vel0.butterDifferentiator(dT, cutoff, N);
	filter_Lft_vel1.butterDifferentiator(dT, cutoff, N);
	filter_Rft_vel1.butterDifferentiator(dT, cutoff, N);

	filter_Lft_vel0.int_diff_filter(Lft_ang[0]);
	filter_Rft_vel0.int_diff_filter(Rft_ang[0]);
	filter_Lft_vel1.int_diff_filter(Lft_ang[1]);
	filter_Rft_vel1.int_diff_filter(Rft_ang[1]);
	is_filter_int = 1;
}


void getStateFeedback(float dT,int LOOP)
{

	robot_state=callRobotState();		// why not directly call the structure? 
	
	Lft_vec = robot_state.IMU_rel*(robot_state.Lft - robot_state.com);  // tested ok
	Rft_vec = robot_state.IMU_rel*(robot_state.Rft - robot_state.com);  // tested ok
	COP_COM_vec = robot_state.IMU_rel*(robot_state.cop-robot_state.com);// tested ok

	th_virtual[0] = atan2(COP_COM_vec(1),-COP_COM_vec(2)); // COM with respect to COP	
	th_virtual[1] = atan2(-COP_COM_vec(0),-COP_COM_vec(2)); // COM with respect to COP

	Lft_ang[0] = atan2(Lft_vec(1),-Lft_vec(2)); // COM with respect to left foot		
	Lft_ang[1] = atan2(-Lft_vec(0),-Lft_vec(2)); // COM with respect to left foot		

	Rft_ang[0] = atan2(Rft_vec(1),-Rft_vec(2)); // COM with respect to right foot		
	Rft_ang[1] = atan2(-Rft_vec(0),-Rft_vec(2)); // COM with respect to right foot		

	if (!is_filter_int)
	{
		initilizeFilter(dT, 5, 1);
	}

	Lft_vel[0] = filter_Lft_vel0.differentiator(Lft_ang[0]);
	Rft_vel[0] = filter_Rft_vel0.differentiator(Rft_ang[0]);
	Lft_vel[1] = filter_Lft_vel1.differentiator(Lft_ang[1]);
	Rft_vel[1] = filter_Rft_vel1.differentiator(Rft_ang[1]);

	//printf("%2.2f \n",Lft_vel[0]);
	//FT_fl_filter;
	//FT_fr_filter;
	//static float time=LOOP*dT;
	if ( LOOP%1==0 )
	{		
		//printf("Left foot: \t x=%2.2f \t y=%2.2f \t z=%2.2f \n",Lft_vec(0),Lft_vec(1),Lft_vec(2));
		//printf("Right foot: \t x=%2.2f \t y=%2.2f \t z=%2.2f \n",Rft_vec(0),Rft_vec(1),Rft_vec(2));
		//printf("COP to COM: \t x=%2.2f \t y=%2.2f \t z=%2.2f \n",COP_COM_vec(0),COP_COM_vec(1),COP_COM_vec(2));

		printf("virtual leg:\t%2.2f \t %2.2f \n", RADTODEG(th_virtual[0]), RADTODEG(th_virtual[1]) );
		printf("left leg:\t%2.2f \t %2.2f \n", RADTODEG(Lft_ang[0]), RADTODEG(Lft_ang[1]) );
		printf("right leg:\t%2.2f \t %2.2f \n", RADTODEG(Rft_ang[0]), RADTODEG(Rft_ang[1]) );

		printf("\n");
		printf("FT_fl_filter: \t x=%2.2f \t y=%2.2f \t z=%2.2f \n",robot_state.FT_fl_filter(0),robot_state.FT_fl_filter(1),robot_state.FT_fl_filter(2));
		printf("FT_fr_filter: \t x=%2.2f \t y=%2.2f \t z=%2.2f \n",robot_state.FT_fr_filter(0),robot_state.FT_fr_filter(1),robot_state.FT_fr_filter(2));

		printf("Global lft: \t x=%2.2f \t y=%2.2f \t z=%2.2f \n",robot_state.glft(0),robot_state.glft(1),robot_state.glft(2));
		printf("Global rft: \t x=%2.2f \t y=%2.2f \t z=%2.2f \n",robot_state.grft(0),robot_state.grft(1),robot_state.grft(2));
		printf("Global COM: \t x=%2.2f \t y=%2.2f \t z=%2.2f \n",robot_state.gcom(0),robot_state.gcom(1),robot_state.gcom(2));
		printf("\n");
	}	
}


//void FPE()
//{
//	static float L, w, Ek0,Ekf, Wg, E, th;
//	static float th_f =DEGTORAD(30);
//	static float g=9.81;
//	static float A, B, C;
//
//	L=Lft_vec.norm();	
//	w=Lft_vel[0];
//	th = Lft_ang[0];
//
//	Ek0 = 0.5*L*L*w*w;
//		
//	Wg = -0.5*g*L*th*th;
//
//	E = Ek0 + Wg;
//
//	printf("will robot fall? \n");
//	if ((E>0&&w<0)||th<0)
//	{
//		printf("YES\n");
//	}
//	else
//	{
//		printf("NO\n");
//	}
//
//	if ( abs(th)<abs(th_f) )
//	{
//		Ekf=Ek0+g*L*(cos(th)-cos(th_f));
//	}
//	else
//	{
//		Ekf=Ek0;
//    }
//	A=Ekf;
//	B=g*L*cos(th_f);
//	C=th_f; // angle before touch down
//	th_attack = ( -2*A*sin(C)+sqrt(4*A*A*sin(C)*sin(C)-4*A*A+8*A*A*cos(C)*cos(C)+2*A*B) )*cos(C)/(-2*A+4*A*cos(C)*cos(C)+B);
//	
//}

void FallPrediction()
{
	static float L_left, w_left[2], Ek0_left[2],Wg_left[2], E_left[2], th_left[2];
	static float L_right, w_right[2], Ek0_right[2],Wg_right[2], E_right[2], th_right[2];
	static float th_f =DEGTORAD(30);
	static float A, B, C;

	L_left=Lft_vec.norm();	
	L_right=Rft_vec.norm();	

	for (int i=0;i<2;i++)
	{
		w_left[i]=Lft_vel[i];
		th_left[i] = Lft_ang[i];	
		
		w_right[i]=Rft_vel[i];
		th_right[i] = Rft_ang[i];

		Ek0_left[i] = 0.5*L_left*L_left*w_left[i]*w_left[i];		
		Wg_left[i] = -0.5*g*L_left*th_left[i]*th_left[i];
		E_left[i] = Ek0_left[i] + Wg_left[i];

		Ek0_right[i] = 0.5*L_right*L_right*w_right[i]*w_right[i];		
		Wg_right[i] = -0.5*g*L_right*th_right[i]*th_right[i];
		E_right[i] = Ek0_right[i] + Wg_right[i];

		th_lr[i]=th_left[i];
		th_lr[2+i]=th_right[i];
		Ek0_lr[i]=Ek0_left[i];
		Ek0_lr[2+i]=Ek0_right[i];
		L_lr[i]=r_left_des;
		L_lr[2+i]=r_right_des;
	}



	for(int i=0;i<4;i++){		
		if ( abs(th_lr[i])<abs(th_f)){
			Ekf_lr[i]=Ek0_lr[i]+g*L_lr[i]*(cos(th_lr[i])-cos(th_f));
		}
		else{
			Ekf_lr[i]=Ek0_lr[i];
		}
		A=Ekf_lr[i];
		B=g*L_lr[i]*cos(th_f);
		C=th_f; // angle before touch down
		th_attack[i] = ( -2*A*sin(C)+sqrt(4*A*A*sin(C)*sin(C)-4*A*A+8*A*A*cos(C)*cos(C)+2*A*B) )*cos(C)/(-2*A+4*A*cos(C)*cos(C)+B);
		L_lr_drop[i]=L_lr[i]*(cos(C)/cos(th_attack[i]));
		fpe[i] = L_lr_drop[i]*sin(th_attack[0]);
	}
	//fpe[0] = /*-Lft_vec(0)+*/ abs(Lft_vec(2))*tan(th_attack[0]);
	//fpe[1] =/* -Lft_vec(1)+*/ abs(Lft_vec(2))*tan(th_attack[1]);
	//fpe[2] =/* -Rft_vec(0)+*/ abs(Rft_vec(2))*tan(th_attack[2]);
	//fpe[3] =/* -Rft_vec(1)+*/ abs(Rft_vec(2))*tan(th_attack[3]);

	



	printf("will robot fall? \n");
	if ( (E_left[0]>0&&w_left[0]<0&& robot_state.FT_foot_left(2)>10)||th_left[0]<DEGTORAD(0)  )
	{
		printf("Fall to left\n");
	}
	else if( (E_right[0]>0&&w_right[0]>0&& robot_state.FT_foot_right(2)>10)||th_right[0]>DEGTORAD(0)  )
	{
		printf("Fall to right\n");
	}
	else
	{
		printf("NOT\t\t\t\n");
	}

	// below for the left support leg
	if ( th_left[1]<0 && w_left[1]<0 && robot_state.FT_foot_left(2)>10 )
	{
		printf("Fall back \t\t\n");
	}
	else if ( th_left[1]<0 && w_left[1]>0 && robot_state.FT_foot_left(2)>10 )
	{
		if (E_left[1]<0)
		{
			printf("Return before apex \n");
		}
		else
		{
			printf("Cross apex, fall to front \n");
		}
	}

	if ( th_left[1]>0 && w_left[1]>0 && robot_state.FT_foot_left(2)>10 )
	{
		printf("Fall front \t\t\n");
	}
	else if ( th_left[1]>0 && w_left[1]<0 && robot_state.FT_foot_left(2)>10 )
	{
		if (E_left[1]<0)
		{
			printf("Return before apex \n");
		}
		else
		{
			printf("Cross apex, fall to back \n");
		}
	}

	// below for the right support leg
	if ( th_right[1]<0 && w_right[1]<0 && robot_state.FT_foot_right(2)>10 )
	{
		printf("Fall back \t\t\n");
	}
	else if ( th_right[1]<0 && w_right[1]>0 && robot_state.FT_foot_right(2)>10 )
	{
		if (E_right[1]<0)
		{
			printf("Return before apex \n");
		}
		else
		{
			printf("Cross apex, fall to front \n");
		}
	}

	if ( th_right[1]>0 && w_right[1]>0 && robot_state.FT_foot_right(2)>10 )
	{
		printf("Fall front \t\t\n");
	}
	else if ( th_right[1]>0 && w_right[1]<0 && robot_state.FT_foot_right(2)>10 )
	{
		if (E_right[1]<0)
		{
			printf("Return before apex \n");
		}
		else
		{
			printf("Cross apex, fall to back \n");
		}
	}

}

void RTControl(float dT, int LOOP,float *traj_ref, float *log_data)
{
	getStateFeedback(dT,LOOP);
	//FPE();
	FallPrediction();
	
	float k=0.5;
	if(dT*LOOP<0.5){
		r_left=r_left_des - 0.05*sin(k*M_PI*dT*LOOP)*sin(k*M_PI*dT*LOOP);
		r_right=r_left_des - 0.05*sin(k*M_PI*dT*LOOP-M_PI)*sin(k*M_PI*dT*LOOP-M_PI);		
	}
	else{
		FPEControl(dT,LOOP);
	}

	
	//static float footplace;
	////Vector3f 
	//footplace = -Lft_vec(1)+ abs(Lft_vec(2))*tan(th_attack);
	//printf("\n");
	//printf("FPE angle (deg):\t=%2.2f\n",RADTODEG(th_attack) );
	//printf("where to place foot before falling out of friction cone\n");
	//printf("FPE y(m):\t=%2.2f",footplace );
		


	//float k=0.5;
	//r_left=r_left_des - 0.03*sin(k*M_PI*dT*LOOP)*sin(k*M_PI*dT*LOOP);
	//r_right=r_left_des - 0.03*sin(k*M_PI*dT*LOOP-M_PI)*sin(k*M_PI*dT*LOOP-M_PI);
	//printf("%2.2f",r_right);
	th_left[0]=DEGTORAD(0)*(1-exp(-0.1*dT*LOOP)); //*sin(0.5*dT*LOOP)*sin(0.5*dT*LOOP);
	th_right[0]=-DEGTORAD(0)*(1-exp(-0.1*dT*LOOP)); //*sin(0.5*dT*LOOP)*sin(0.5*dT*LOOP);

	//th_left[1]=0.1*sin(dT*LOOP);
	//th_right[1]=-0.1*sin(dT*LOOP);
	//th_left[2]=DEGTORAD(80)*sin(dT*LOOP);
	//th_right[2]=-DEGTORAD(80)*sin(dT*LOOP);
	log_data[LOOP*8]=Lft_ang[0];
	log_data[LOOP*8+1]=Lft_vel[0];
	log_data[LOOP*8+2]=Rft_ang[0];
	log_data[LOOP*8+3]=Rft_vel[0];
	log_data[LOOP*8+4]=Lft_ang[1];
	log_data[LOOP*8+5]=Lft_vel[1];
	log_data[LOOP*8+6]=Rft_ang[1];
	log_data[LOOP*8+7]=Rft_vel[1];

	WholeLegInvK(th_left, r_left, LFtO, th_right, r_right, RFtO, traj_ref);
}