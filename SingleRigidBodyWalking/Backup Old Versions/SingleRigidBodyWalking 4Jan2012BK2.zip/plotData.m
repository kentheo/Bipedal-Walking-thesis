endpoint = size(store_grf,1);

figure(2); clf; 
subplot(3,1,1); hold on; title('contact forces')
plot(time(1:endpoint),store_grf(:,1))
subplot(3,1,2); plot(time(1:endpoint),store_grf(:,2))
subplot(3,1,3); plot(time(1:endpoint),store_grf(:,3))

figure(3); clf; 
subplot(3,1,1); hold on; title('contact point position')
plot(time(1:endpoint),store_p(:,1))
subplot(3,1,2); plot(time(1:endpoint),store_p(:,2))
subplot(3,1,3);  %hold on; grid on; 
plot(time(1:endpoint),store_p(:,3)) 

figure(4); clf; 
subplot(3,1,1); hold on;  title('contact point velocity')
plot(time(1:endpoint),store_v(:,1))
% plot(time,[0;diff(store_pc(:,1))/Dtime],'r')
subplot(3,1,2); plot(time(1:endpoint),store_v(:,2))
subplot(3,1,3); hold on; %grid on;
plot(time(1:endpoint),store_v(:,3))
% plot(time,[0;diff(store_pc(:,3))/Dtime],'r')

% return;

figure(5); clf;
subplot(3,1,1); hold on; title('COM positiom')
plot(time(1:endpoint),store_pcom(:,1))
% plot(time,store_vc(:,1),'g')
subplot(3,1,2); plot(time(1:endpoint),store_pcom(:,2))
subplot(3,1,3); plot(time(1:endpoint),store_pcom(:,3))

figure(6); clf; 
subplot(3,1,1); hold on; title('COM velocity')
plot(time(1:endpoint),store_vcom(:,1))
% plot(time,store_vc(:,1),'g');
% plot(time,[0;diff(store_pcom(:,1))/Dtime],'g')
% legend('vcom')
subplot(3,1,2); hold on;
plot(time(1:endpoint),store_vcom(:,2))
% plot(time,[0;diff(store_pcom(:,2))/Dtime],'g')
subplot(3,1,3); hold on;
plot(time(1:endpoint),store_vcom(:,3))
% plot(time,store_vc(:,3),'g');
% plot(time,[0;diff(store_pcom(:,3))/Dtime],'g')
% legend('vcom','vcom')