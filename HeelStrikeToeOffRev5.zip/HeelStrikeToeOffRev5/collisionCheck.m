function [status]=collisionCheck(p1,p2,v1,v2);


%we use the theory discribed in work of guan

Ap1p2v1=(p1(1)*(p2(2)-v1(2))+p2(1)*(v1(2)-p1(2))+v1(1)*(p1(2)-p2(2)));
Ap1p2v2=(p1(1)*(p2(2)-v2(2))+p2(1)*(v2(2)-p1(2))+v2(1)*(p1(2)-p2(2)));
Av1v2p1=(v1(1)*(v2(2)-p1(2))+v2(1)*(p1(2)-v1(2))+p1(1)*(v1(2)-v2(2)));
Av1v2p2=(v1(1)*(v2(2)-p2(2))+v2(1)*(p2(2)-v1(2))+p2(1)*(v1(2)-v2(2)));

if max(Ap1p2v1*Ap1p2v2,Av1v2p1*Av1v2p2)>0
    status=1;  %collision free
else
    status=-1; %collision occurs
end