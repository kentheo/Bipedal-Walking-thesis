function [xf,yf,zf,rotY_f,rotZ_f]=TrajStanceLeg(xposstanceleg,yposstanceleg,rotZstanceleg);

    xf=xposstanceleg;

    yf=yposstanceleg;

    zf=0.0;
    rotY_f = 0.0;
    rotZ_f=rotZstanceleg;  