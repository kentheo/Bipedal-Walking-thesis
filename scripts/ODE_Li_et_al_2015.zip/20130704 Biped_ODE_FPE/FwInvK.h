//extern void InvKHIP(float HipP[3], float HipO[4], float LeftFootP[3], float LFtO[4], float RightFootP[3], float RFtO[4], float *homePos,float *traj_ref);

//extern void ArmIKTrajectory(float BodyP[3], float BodyO[3],float LeftHandP[3],float yawArmL, float RightHandP[3],float yawArmR,float *traj);
//extern void ArmFWTrajectory(float q[], float armL[6], float armR[6]);
//extern void LegFWTrajectory(float q[], float legL[6], float legR[6]);
//extern Vector3f LegFWTrajectory(float q[], float legL[6], float legR[6]);
//extern Vector3f WholeBodyState(float q[], Matrix3f Rwaist, float legL[6], float legR[6]);

//extern void newInvKHIP(float HipP[3], float HipO[4], float LeftFootP[3], float LFtO[4], float FootL[3], float RightFootP[3], float RFtO[4],float FootR[3], float *homePos,float *traj_ref);

//extern void InvKLeg(float theta_left[3], float r_left, float LFtO[4], float FootL[3], float theta_right[3], float r_right, float RFtO[4],float FootR[3], float *homePos,float *traj_ref);

extern void WholeLegInvK(float theta_left[3], float r_left, float LFtO[4], float theta_right[3], float r_right, float RFtO[4],float *traj_ref);