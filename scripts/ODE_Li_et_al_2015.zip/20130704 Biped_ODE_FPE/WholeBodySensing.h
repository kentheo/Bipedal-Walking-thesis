#ifndef WholeBodySensing
#define WholeBodySensing

#include "COMANParameter.h"

#include "MatrixVector.h"
#include <iostream>
using namespace std;

#define _USE_MATH_DEFINES // this is for using <cmath>
#include <cmath>

typedef Matrix< int , 5 , 1> Vector5i;
typedef Matrix< float , 6 , 1> Vector6f;

struct segment {
	float m;
	Vector3f dcom;
	Vector3f limb;
	//Vector3f rcom;
	//Matrix3f R;
};

struct _link {
	float m;
	Vector3f q;  // refer (x,y,z) rotation angle
	Vector3f dq; // refer angular velocity
	Vector3f ddq;// refer angular acceleration
	Vector3f q_old;  
	Vector3f dq_old;
	Vector3f ddq_old;

	Vector2f qcom;  // refer (x,y,z) rotation angle about TotalCOM
	Vector2f dqcom; // refer angular velocity about TotalCOM
	Vector2f qcom_old;  

	//Vector3f qmotor;  // motor (x,y,z) rotation angle
	//Vector3f dqmotor; // motor angular velocity
	//Vector3f ddqmotor;// motor angular acceleration
	//Vector3f qlink_abs;  // link_abs (x,y,z) rotation angle
	//Vector3f dqlink_abs; // link_abs angular velocity
	//Vector3f ddqlink_abs;// link_abs angular acceleration
	//Vector3f qdef;  // deflection (x,y,z) rotation angle
	//Vector3f dqdef; // deflection angular velocity
	//Vector3f ddqdef;// deflection angular acceleration
	//Vector3f link_torque;
	//Vector3f k_spring;

	Vector3f ft_com; // com in support foot coordinate's frame
	Vector3f ft_dcom;
	Vector3f ft_ddcom;
	Vector3f ft_joint;

	Vector3f pcom; // link's com position in TotalCOM frame

	Vector3f dcom; // link's com in the link local frame
	Vector3f limb; // link dimension
	Vector3f rcom; // link's com in the waist frame
	Vector3f drcom; // link's com velocity in the waist frame
	Vector3f ddrcom; // link's com acceleration in the waist frame
	Vector3f rcom_old; 
	Vector3f drcom_old; 
	Vector3f ddrcom_old; 
	Vector3f Lcom; // angular momentum around COM
	Vector3f joint; // position vector of joint 
	Vector3f joint_old;
	Matrix3f R; // rotational matrix of link
	Matrix3f Icom; // inertia tensor around TotalCOM
	string name; // name of the segment
};

struct _joint{
	Vector3f a;
	Vector3f aw;
	Vector3f p;	// current joint position in HIP frame
	Vector3f pn;// current joint to end effector
	Vector6f J;
};

enum SupportState{   
 OnBothFeet, // Standing on both feet   
 OnLFoot,    
 OnRFoot,    
 NotOnFoot,
};

enum walkstate{
 STAND,
 L_PUSH,
 L_LIFT,
 L_SWING,
 L_DROP,
 R_PUSH,
 R_LIFT,
 R_SWING,
 R_DROP, 
};

enum opstate{   
 STOP,
 WALK,
 MANUAL,
};


struct _irobot{
	_link LINK[3][5];
	float m;
	Vector5i id;
	Vector3i seg;
	int idno;
	int segno;
	float dt;
	Vector3f com;  // overall COM
	Vector3f dcom; // COM velocity
	Vector3f ddcom;// COM acceleration
	Vector3f com_old;
	Vector3f dcom_old; 
	Vector3f ddcom_old;
	Vector3f Lcom; // overall angular momentum around COM
	Vector3f dLcom;
	Vector3f Lcom_old;
	Vector3f dLcom_old;
	Vector3f Lft;
	Vector3f Rft;
	Vector3f Larm;
	Vector3f Rarm;
	Vector2f calcZMP;
	
	SupportState WhichFoot;
	mutable walkstate WalkingState;
	mutable opstate Mode;

	Vector3f fOrigin; // origin in support foot coordinate's frame
	Vector3f ft_com; // com in support foot coordinate's frame
	Vector3f ft_dcom;
	Vector3f ft_ddcom;
	Vector3f gOrigin; // fOorigin in global frame
	Vector3f gcom; // com in global frame
	Vector3f gcom_old;
	Vector3f gdcom;
	Vector3f gddcom;
	Vector3f ghip;
	Vector3f glft;
	Vector3f grft;
	Vector3f glft_old;
	Vector3f grft_old;
	Vector3f leftstance;
	Vector3f rightstance;
	Vector3f leftstance_old;
	Vector3f rightstance_old;
	
	Vector6f FT_foot_left; // F/T sensor feedback
	Vector6f FT_foot_right;
	Vector6f FT_fl_filter; // filtered F/T sensor feedback
	Vector6f FT_fr_filter;
	//Vector6f FT_hand_left;
	//Vector6f FT_hand_right;
	Matrix3f IMU_abs;
	Matrix3f IMU_rel;
	Matrix3f Icom; // total inertia tensor around COM

	Vector2f dQavg; 
	Vector3f IMU_angle;
	Vector3f IMU_angle_old;
	Vector3f IMU_d_angle;
	float FPEAngle;
	float FPEGndPos;

	Vector3f lcop; // left foot COP
	Vector3f rcop; // right foot COP
	Vector3f glcop; // left foot COP in GLOBAL frame
	Vector3f grcop; // right foot COP in GLOBAL frame
	Vector3f dlcop; // left foot COP velocity
	Vector3f drcop; // right foot COP velocity
	Vector3f cop; // overall COP in hip frame
	Vector3f dcop; // overall COP velocity in support foot fram
	Vector3f cop_in_lft; // overall COP in left foot frame
	Vector3f cop_in_rft; // overall COP in right foot frame
	Vector3f lcop_delta;
	Vector3f rcop_delta;
	Vector3f cop_delta;

	Matrix<float, 6, 6> Jlf;
	Matrix<float, 6, 6> Jrf;
	Matrix<float, 6, 8> Jlarm;
	Matrix<float, 6, 8> Jrarm;
};

extern void CallDataStructure(float qL[6],float qR[6],float qW[3],float qaL[4],float qaR[4],float dt,Matrix3f Rpelvis_abs,float FTSensor[12]);
extern _irobot callRobotState();
extern void SetRobotWalkState(opstate Mode);

#endif