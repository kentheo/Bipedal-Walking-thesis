#include "ActuatorClass.h"
#define _USE_MATH_DEFINES
#include <cmath>

float ActuatorClass::ActuatorUnit(float T, float real_time, float target_time, float target_pos,float v_limit,float a_limit, float fn) // default target velocity is zero.
{
    static float dds0; // previous state of s
    static float ds0; 
    static float s0;  
	static float ds0_old;    
	static float s;		// interpolated s
	static float s_filter[3];	// proxy control filtered s    
	static float s_filter_old[3];
	static float target_vel = 0;  // default velocity at target position
	static float output;

    s=Poly3Intpl(real_time+T, real_time, ds0, s0, target_time, target_vel, target_pos);
    
	ds0_old=ds0;
    ds0=(s-s0)/T;     
	dds0=(ds0-ds0_old)/T;      
    s0 = s; 
    
    Proxy_Model(T, s_filter_old, s, fn, v_limit, a_limit, s_filter);
	s_filter_old[0] = s_filter[0];
	s_filter_old[1] = s_filter[1];
	s_filter_old[2] = s_filter[2];
	output=s_filter[0];
    return output;    
}



float ActuatorClass::Poly3Intpl(float time, float t0, float ds0, float s0, float tf, float dsf, float sf)
{
	static float a0,a1,a2,a3,t,s;
	//below is the general 3rd order polynomial        
    a0=s0;
    a1=ds0; 
    a2=(3*(sf-s0) -(2*ds0+dsf)*(tf-t0) ) /  ( (tf-t0)*(tf-t0) );
    a3=(-2*(sf-s0) + (ds0+dsf)*(tf-t0) ) / ( (tf-t0)*(tf-t0)*(tf-t0) ) ;
    t=time-t0;
	if (time<=t0)
	{
		s=s0;
	}
	else if (time>=tf)
	{
		s=s0+0.05*(sf-s0);
	}
    else
	{
		s=a0+a1*t+a2*t*t+a3*t*t*t;
	}		
	return s;
}


void ActuatorClass::Proxy_Model(float T, float xnow[3], float xdes, float fn, float v_limit, float a_limit, float *s_filter)
{
	static float wn,K,damp,C,a,dx,ddx;
	static float Tfilter = 1.0/50.0;  // default bandwidth of force/torque
	
	wn=2*M_PI*fn;
	K=wn*wn;
	damp=2.0;
	C=2*damp*wn;

	a = K*(xdes - xnow[0]) - C*xnow[1];

	ddx = (Tfilter*xnow[2]+T*a)/(Tfilter+T);  // filter the acceleration to have min jerk, avoid sharp motion

	if (ddx>a_limit)   // acceleration limit
	{
		ddx=a_limit;
	}
	else if (ddx<-a_limit)
	{
		ddx=-a_limit;
	}	
	dx= xnow[1]+ddx*T;

	if (dx>v_limit)  // velocity limit
	{
		dx=v_limit;
	}
	else if (dx<-v_limit)
	{
		dx=-v_limit;
	}

	s_filter[0] = xnow[0] + 0.5*(xnow[1]+dx)*T;
	s_filter[1] = dx;
	s_filter[2] = (dx-xnow[1])/T;
}