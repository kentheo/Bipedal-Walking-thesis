clear all; close all; clc;

COM_ode = load('ODEdata.txt');
COM_est = load('CPPdata.txt');

data = load('log_data.txt');
%%
dT = 0.005;

% figure(1); clf; hold on
% % plot( [COM_ode(:, end-3:end), COM_est(:,7:9) ] );
% plot(COM_ode(:, end-3:end),'r');
% plot(COM_est(:,7:9),'.')

figure(2); clf; hold on;
plot([0;diff(data(:,1))./dT]);
plot(data(:,2),'r');

figure(3); clf; hold on;
plot([0;diff(data(:,3))./dT]);
plot(data(:,4),'r');

figure(4); clf; hold on;
plot([0;diff(data(:,5))./dT]);
plot(data(:,6),'r');

figure(5); clf; hold on;
plot([0;diff(data(:,7))./dT]);
plot(data(:,8),'r');


figure(6); clf; hold on;
plot(data(:,1));
plot(data(:,3),'r');

figure(7); clf; hold on;
plot(data(:,5));
plot(data(:,7),'r');