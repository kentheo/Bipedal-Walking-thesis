// here decleare the functions in RTControl.cpp that will be used by other cpp files.
//extern void getStateFeedback();
extern void RTControl(float dT, int LOOP, float *traj_ref, float *log_data);

extern void SetWalkState(opstate Mode);