#include "FPEControl.h"
// below are state variables
_irobot irobot_state; // log out data structure
Vector3f Lft_com, Rft_com;
const float StepForwardThreshold = 0.01;
const float StepBehindThreshold = 0.01;
const float Swing_Trans_Thres=0.01;
float Lift_Height=0.05;

float KneeRate=0.005;
float HipRate=0.005;
float SwingKneeRate=0.01;
float SwingHipRate=0.02;
float FminFPE=30;

walkstate WalkingState;
opstate WalkMode;

//////////////////////////////////////////////////////
void SetWalkState(opstate Mode)
{
	WalkMode=Mode;
}

void FPEControl(float *traj_ref,float *fpepos)
{
	irobot_state=callRobotState();		// why not directly call the structure? 

	Lft_com = irobot_state.IMU_rel*(irobot_state.Lft - irobot_state.com);
	Rft_com = irobot_state.IMU_rel*(irobot_state.Rft - irobot_state.com);

	bool LftLead= Lft_com(0) > Rft_com(0);
	bool RftLead= Lft_com(0) < Rft_com(0);
	bool FPELead= (fpepos[0] - LftLead*Lft_com(0)) > StepForwardThreshold;
	bool FPEBack= (fpepos[2] - (RftLead*Lft_com(0)+LftLead*Rft_com(0))) < -StepBehindThreshold;
	
	float qLleg[6],qRleg[6];

	for(int i=0;i<3;i++){
		qLleg[i]=irobot_state.LINK[0][1].q(i);
		qRleg[i]=irobot_state.LINK[0][2].q(i);
	}
	qLleg[3]=irobot_state.LINK[1][1].q(1);
	qRleg[3]=irobot_state.LINK[1][2].q(1);
	qLleg[4]=irobot_state.LINK[2][1].q(0);
	qRleg[4]=irobot_state.LINK[2][2].q(0);
	qLleg[5]=irobot_state.LINK[2][1].q(1);
	qRleg[5]=irobot_state.LINK[2][2].q(1);	

	FPELead=1;

	if(WalkingState==STAND){
		if(LftLead){
			if(WalkMode==WALK){
				WalkingState=R_PUSH;			
			}
			else if(FPELead){
				WalkingState=R_LIFT;
			}
			else if(FPEBack){
				WalkingState=L_LIFT;
			}
		}
		else if(RftLead){
			if(WalkMode==WALK){
				WalkingState=L_PUSH;			
			}
			else if(FPELead){
				WalkingState=L_LIFT;
			}
			else if(FPEBack){
				WalkingState=R_LIFT;
			}
		}
		else{ // ˫�Ų���վ��
			WalkingState=L_LIFT;
		}
	}

	else if(WalkingState==L_PUSH){
		if(FPELead){
			WalkingState=L_LIFT;
		}
		else if(FPEBack){
			WalkingState=R_LIFT;
		}
		else{
			qRleg[0]=irobot_state.LINK[0][2].q(0)+irobot_state.IMU_angle(1);//to hold torso upright		
			qLleg[3]=irobot_state.LINK[1][1].q(1)-KneeRate;
		}
	}

	else if(WalkingState==L_LIFT){
		qRleg[0]=irobot_state.LINK[0][2].q(0)+irobot_state.IMU_angle(1);	
		//qRleg[1]=irobot_state.LINK[0][2].q(1)+HipRate;
		if((-irobot_state.Rft(2)+irobot_state.Lft(2) < Lift_Height)){
			qLleg[3]=irobot_state.LINK[1][1].q(1)+KneeRate;
			qLleg[0]=irobot_state.LINK[0][1].q(0)-HipRate;
		}
		else{
			WalkingState=L_SWING;
		}
	}

	else if(WalkingState==L_SWING){
		qRleg[0]=irobot_state.LINK[0][2].q(0)+irobot_state.IMU_angle(1);

		if((irobot_state.Rft(2)-irobot_state.Lft(2) < Lift_Height)){
			qLleg[3]=irobot_state.LINK[1][1].q(1)+SwingKneeRate;
		}
		else{
			qLleg[3]=irobot_state.LINK[1][1].q(1)-SwingKneeRate;
		}

		if(abs(fpepos[0] - Lft_com(0)) > Swing_Trans_Thres){
			qLleg[0]=irobot_state.LINK[0][1].q(0) - SwingHipRate;
		}
		else{
			WalkingState=L_DROP;
		}	
	}

	else if(WalkingState==L_DROP){
		qRleg[0]=irobot_state.LINK[0][2].q(0)+irobot_state.IMU_angle(1);

		if(irobot_state.FT_fl_filter(2)<FminFPE){
			qLleg[3]=irobot_state.LINK[1][1].q(1)-KneeRate;
			if(abs(irobot_state.FPEGndPos - Lft_com(0)) > Swing_Trans_Thres){
				if((irobot_state.FPEGndPos - Lft_com(0)) > Swing_Trans_Thres){
					qLleg[0]=irobot_state.LINK[0][1].q(0) - HipRate;
				}
				else{
					qLleg[0]=irobot_state.LINK[0][1].q(0) + HipRate;
				}
			}
		}
		else{
			if(WalkMode==WALK){
				WalkingState=R_PUSH;
			}
			else{
				WalkingState=STAND;
			}		
		}
	}
	///// Right Foot
	else if(WalkingState==R_PUSH){
		if(FPELead){
			WalkingState=R_LIFT;
		}
		else if(FPEBack){
			WalkingState=L_LIFT;
		}
		else{
			qLleg[0]=irobot_state.LINK[0][1].q(0)+irobot_state.IMU_angle(1);//to hold torso upright		
			qRleg[3]=irobot_state.LINK[1][2].q(1)-KneeRate;
		}
	}

	else if(WalkingState==R_LIFT){
		qLleg[0]=irobot_state.LINK[0][1].q(0)+irobot_state.IMU_angle(1);
		//qLleg[1]=irobot_state.LINK[0][1].q(1)+HipRate;
		if((-irobot_state.Lft(2)+irobot_state.Rft(2) < Lift_Height)){
			qRleg[3]=irobot_state.LINK[1][2].q(1)+KneeRate;
			qRleg[0]=irobot_state.LINK[0][1].q(0) - HipRate;
		}
		else{
			WalkingState=R_SWING;
		}
	}

	else if(WalkingState==R_SWING){
		qLleg[0]=irobot_state.LINK[0][1].q(0)+irobot_state.IMU_angle(1);		

		if((irobot_state.Lft(2)-irobot_state.Rft(2) < Lift_Height)){
			qRleg[3]=irobot_state.LINK[1][2].q(1)+SwingKneeRate;
		}
		else{
			qRleg[3]=irobot_state.LINK[1][2].q(1)-SwingKneeRate;
		}

		if(abs(fpepos[3] - Rft_com(0)) > Swing_Trans_Thres){
			qRleg[0]=irobot_state.LINK[0][2].q(0) - SwingHipRate;
		}
		else{
			WalkingState=R_DROP;
		}	
	}

	else if(WalkingState==R_DROP){
		qLleg[0]=irobot_state.LINK[0][1].q(0)+irobot_state.IMU_angle(1);		

		if(irobot_state.FT_fr_filter(2)<FminFPE){
			qRleg[3]=irobot_state.LINK[1][2].q(1)-KneeRate;
			if(abs(irobot_state.FPEGndPos - Rft_com(0)) > Swing_Trans_Thres){
				if((irobot_state.FPEGndPos - Rft_com(0)) > Swing_Trans_Thres){
					qRleg[0]=irobot_state.LINK[0][1].q(0) - HipRate;
				}
				else{
					qRleg[0]=irobot_state.LINK[0][1].q(0) + HipRate;
				}
			}
		}
		else{
			if(WalkMode==WALK){
				WalkingState=L_PUSH;
			}
			else{
				WalkingState=STAND;
			}		
		}
	}

	traj_ref[3]=qRleg[0];
	traj_ref[4]=qLleg[0];
	for(int i=5;i<(5+5);i++){
		traj_ref[i]=qLleg[i-4];
		traj_ref[i+5]=qRleg[i-4];
	}

}
