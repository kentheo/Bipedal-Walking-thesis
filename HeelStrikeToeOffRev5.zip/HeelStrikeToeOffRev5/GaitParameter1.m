function [LambdaX,LambdaY,Alpha_foot,Nu,Lift,Wait, LeftFootMoving]=GaitParameter1
global totalnumberofsteps hip_Comy  numberofsteps
global step_width Tcycle Height steplength

steps = numberofsteps;
% i find lift height 0.04 is a bit high for real icub walking


velo=2*steplength/Tcycle;	%0.22;


%%%%%%%%%%%%
LambdaX(1)= 0.5*steplength;    % step length 0.15 angle of attack is nearly 71.3885
LambdaY(1)=-((-1)^1)*step_width*hip_Comy*2.0;    % outside edge y position of footprint
Alpha_foot(1)=0;
Nu(1)= 0.2*velo; %walking speed
Lift(1)=1*Height;   % height of the lift
Wait(1)=0;  % waiting moment after DS phase
LeftFootMoving(1)=(-(-1)^1+1)/2;    % 1 should mean swing leg

LambdaX(2)= 0.5*steplength;    % step length 0.15 angle of attack is nearly 71.3885
LambdaY(2)=-((-1)^2)*step_width*hip_Comy*2.0;    % outside edge y position of footprint
Alpha_foot(2)=0;
Nu(2)= 0.5*velo; %walking speed
Lift(2)=1*Height;   % height of the lift
Wait(2)=0;  % waiting moment after DS phase
LeftFootMoving(2)=(-(-1)^2+1)/2;    % 1 should mean swing leg

for i=3:steps-2
LambdaX(i)=steplength;    % step length 0.15 angle of attack is nearly 71.3885
LambdaY(i)=-((-1)^i)*step_width*hip_Comy*2.0;    % outside edge y position of footprint

Alpha_foot(i)=0*pi/180; %30*(rand(1)-0.5)*pi()/180; 

Nu(i)=velo; %walking speed
Lift(i)=Height;   % height of the lift
Wait(i)=0;  % waiting moment after DS phase
LeftFootMoving(i)=(-(-1)^i+1)/2;    % 1 should mean swing leg
end
% 
LambdaX(steps-1)=0.5*steplength;    % step length 0.15 angle of attack is nearly 71.3885
LambdaY(steps-1)=-((-1)^(steps-1))*step_width*hip_Comy*2.0;    % outside edge y position of footprint
Alpha_foot(steps-1)=0;
Nu(steps-1)=0.5*velo; %walking speed
Lift(steps-1)=1*Height;   % height of the lift
Wait(steps-1)=0;  
LeftFootMoving(steps-1)=(-(-1)^(steps-1)+1)/2; 

LambdaX(steps)=0.0*steplength;    % step length 0.15 angle of attack is nearly 71.3885
LambdaY(steps)=-((-1)^steps)*1*hip_Comy*2.0;    % outside edge y position of footprint
Alpha_foot(steps)=0;
Nu(steps)=0.2*velo; %walking speed
Lift(steps)=1*Height;   % height of the lift
Wait(steps)=0;  
LeftFootMoving(steps)=(-(-1)^steps+1)/2; 

totalnumberofsteps = steps;